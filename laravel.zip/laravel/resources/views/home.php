<!DOCTYPE html>
<html>
<head>
<title>home</title>
</head>
<style type="text/css">
  body {
background:  linear-gradient(to top, #33ccff 0%, #ff99cc 100%);
} 
  header nav{
    text-align: center;
  }
  header nav a{
    text-decoration: none;
    font-size: 20px;
    color: black;
    padding: 20px;
  }
   header nav a:hover{
    background-color: pink;
    width:5px;
  }
  img{
    margin-left: 650px;
  }
  body, html {
    height: 100%;
}

/* The hero image */
.hero-image {
  background-image:  url("/pictures/h5.jpg");
  height: 40%;
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;
  position: relative;
  margin-top: 0%;
 
}

/* Place text in the middle of the image */
.hero-text h1 {
  text-align: left;
  position: absolute;
  top: 20%;

  left: 30%;
  transform: translate(-50%, -50%);
  color: white;
  font-size: 35px;
  font-family: georgia;


}
.hero-text h2 {
  text-align: left;
  position: absolute;
  top: 20%;
  right: 35%;
  left:25%;
  bottom: 100%;
  transform: translate(-50%, -50%);
  color: white;
  font-size: 45px;
  font-family: georgia;
  font-weight: bold;
}
.hero-text p{
  text-align: left;
  position: absolute;
  top: 40%;
  right: 35%;
  left:25%;
  bottom: 100%;
  transform: translate(-50%, -50%);
  color: white;
  font-size: 30px;
  font-family: georgia;
  font-weight: bold;
}



.article {
  position: fixed;
  left: 0;
 margin-top: 250px;
 height:20px;
  width: 100%;
background: radial-gradient(circle, pink, blue);
  color: black;
  font-size: 15px;
  text-align: center;
}

p{
  text-align: center;
  font-size: 15px;
  font-family: georgia;
  font-weight: bold;
}
.section {
  left: 0;
  bottom: 0;
  height:20%;
  width: 100%;
 background: linear-gradient(to left, #eecda3,#ef629f);
  color: black;
  
}
h3 p{
  font-size: 20px;
  font-weight: bold;
  font-family: sans-serif;
  text-align: center;
}
.footer {

  left: 0;
  bottom: 0;
  height:20%;
  width: 100%;
  background:linear-gradient(to left, #2193b0,#6dd5ed);
  color: black;
  text-align: center;
}


</style>
<body>
	
<header>
<img src="/pictures/roseanne.png" align="center" width="50"  >
<nav>
<a href=" home">Home</a>
    <a href="about">About </a>
    <a href="contact">Contact</a>
 
</nav>
</header>

<div class="hero-image">
  <div class="hero-text">
    <h1>Kon'nichiwa
</h1>
    <h2>I'm Roseanne Angeles</h2>
    <pre>
    <p>Welcome to My Portfolio<p></pre>
  </div>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>

<p> "Travel while we're Young !, Enjoy Life!"</p>
<p>Travelling is a great experienced while you are living. Discovering a beautiful scenario that will make us amaze,And appreciate the place that was given to us by our creator.Also by travelling, we can meditate ourselves from stress and problems.Enjoying the view, Capturing scenarios , and making a memories.Enjoy the precious time in a precious scenarios. A scenarios that can give you a full definition of happiness. "You only live once"</p>

<br>

<div class="section" align="bottom">
 <h3> <p> "The Journey of a thousand miles begins with a single step"-Anonymous</p></h3>
</div>
	
<div class="footer" align="bottom">
  <p>COPYRIGHT 2021 @Angeles</p>
</div>

  </body>
  </html>