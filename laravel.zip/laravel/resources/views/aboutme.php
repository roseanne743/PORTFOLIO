<!DOCTYPE html>
<html>
<head>
	<title>aboutme</title>
	</head>
	<style type="text/css">
		 body {
background:  linear-gradient(to top, #33ccff 0%, #ff99cc 100%);
} 
  header nav{
    text-align: center;
  }
  header nav a{
    text-decoration: none;
    font-size: 20px;
    color: black;
    padding: 20px;
  }
   header nav a:hover{
    background-color: pink;
    width:5px;
  }
  img{
    margin-left: 600px;
  }
  body, html {
    height: 100%;
}
img {
  border-radius: 150px;
  margin-left: 595px;
}

img {
  border-radius: 100px;
  margin-left: 595px;

}
 img {
  border-radius: 100px;
  margin-left: 595px;

}

.boxed {

  border: 2px solid blue ;
  border-width:3px;
  width:700px;
  height:300px;
 margin-right: 200px;
 margin-left: 320px;
 background-image: url("/pictures/last.jpg");
  }


p{
    font-size: 16px;
    font-weight: bold;
    font-family: sans-serif;
    text-align: center;
  }

  .footer {

 margin-left:0%;
  height:10%;
  width: 100%;
  background:linear-gradient(to left, #2193b0,#6dd5ed);
  color: black;
  text-align: center;
}

	</style>

<body>
<header>
<img src="/pictures/roseanne.png" align="center" width="50"  >
<nav>
<a href=" home">Home</a>
    <a href="about">About </a>
    <a href="contact">Contact</a>
 
</nav>
</header>

<img src="/pictures/like.jpg" width="100px" >


<br>
<div class="boxed"  >
<p>   Kon'nichiwa, This is Roseanne Diolazo Angles.</p>
<p>21 years of age , living in Calepaan , Asingan , Pangasinan </p>
<p>A Filipino citizen </p>
<p>Studying at Urdaneta City University, a Third year I.T student</p>
<p> I love writing a poem, watching  a lovestory movie  and of course travelling</p>
<p>I have many travel destinations like Batanes, Cebu ,Sagada ,Siargao, Hamsterdam, Paris, Japan ,Maldives.</p>
<p>At the right time I can also reach my dream destinations.<br>
<br>
“Travel far enough, you meet yourself”– David Mitchell
</p>
</div>
<div class="footer" align="bottom">
  <p>COPYRIGHT 2021 @Angeles</p>
</div>

</body>
</html>