<!DOCTYPE html>
<html>
<head>

<title>home</title>
<style type="text/css">
	

{
  margin: 0;
  padding: 0;
}
 body {
background:  linear-gradient(to top, #e55d87,#5fc3e4);
}

  header nav{
    text-align: center;
  }
  header nav a{
    text-decoration: none;
    font-size: 20px;
    color: black;
    padding: 5px;
  }
  
  header nav a:hover{
    background-color: pink;
    width:5px;
  }
   img{
    margin-left: 600px;
  }



  h1{
    text-align: center;
    font-size: 25px;
    font-weight: bold;
  }
  p{
     text-align: center;
    font-size: 25px;
    font-weight: bold;
  }
  img {
  border-radius: 100px;
  margin-right: 350px;
}
.footer {

left: 0;
  bottom: 0;
  height:20%;
  width: 100%;
  background:linear-gradient(to left, #2193b0,#6dd5ed);
  color: black;
  text-align: center;
}


</style>
</head>

<body>
	
<header>
<img src="/pictures/roseanne.png" align="center" width="50"  >
<nav>
<a href="home">Home</a>
    <a href="aboutme">About </a>
    <a href="contact">Contact</a>
  
</nav>
</header>
<br>



  
  <img src="/pictures/contact.jpg" width="250" height="200" alt="Image2" >


<br>
<h1>Contact: Roseanne D. Angeles</h1>
<p>email : Roseanneangeles@gmail.com</p>
<br>
<br>
<br>
<br>
<br>
<br>
<div class="footer" align="bottom">
  <p>COPYRIGHT 2021 @Angeles</p>
</div>

</body>
</html>